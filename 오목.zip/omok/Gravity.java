package omok;

import java.io.*;

public class Gravity {

	private Map map;
	private DrawBoard d;
	static int Max = 2, Min = 0; // AI_ MIN_MAX �Ǵ��ϴ� ����
	static int[][] Gboard; // ����ġ�� �����ϴ� �迭
	private int defence = 0; //���� ��� ����

	public void XYset(int x, int y) { 
		
		int setX =0;
		int setY =0;

		Gboard[y][x] = Max = 2; //ó���� ������ �浹
		
		for (int i = 0; i < Gboard.length; i++) { //defense ����
			for (int j = 0; j < Gboard.length; j++) {
				if (Gboard[i][j] == 2 && Gboard[i - 1][j] == 2 && Gboard[i + 1][j] == 2){
					defence = 1;
				}else if(Gboard[i][j] == 2 && Gboard[i][j - 1] == 2 && Gboard[i][j + 1] == 2){
					defence = 1;
				}else if(Gboard[i][j] == 2 && Gboard[i - 1][j + 1] == 2 && Gboard[i + 1][j - 1] == 2){
					defence = 1;
				}else if(Gboard[i][j] == 2 && Gboard[i - 1][j - 1] == 2 && Gboard[i + 1][j + 1] == 2) {
					defence = 1;
				} else {
					defence = 0;
				}

			}
		}
		
		for (int i = 0; i < Gboard.length; i++) { // ó�� ���� - user�� ���� ���´�.
			for (int j = 0; j < Gboard.length; j++) {
				if (Gboard[i][j] == 2) {
					if (Gboard[i - 1][j - 1] != 2 && Gboard[i][j - 1] != 2
							&& Gboard[i + 1][j - 1] != 2
							&& Gboard[i - 1][j] != 2 && Gboard[i + 1][j] != 2
							&& Gboard[i - 1][j + 1] != 2
							&& Gboard[i][j + 1] != 2
							&& Gboard[i + 1][j + 1] != 2) {
						Gboard[i - 1][j - 1] = Gboard[i][j - 1] = Gboard[i + 1][j - 1] = Gboard[i - 1][j] = Gboard[i + 1][j] = Gboard[i - 1][j + 1] = Gboard[i][j + 1] = 3;
						Gboard[i + 1][j + 1] = 3;
					}
				}
			}
		}
		System.out.println("defence = " + defence);
		// defence check
		

		// Gboard ����ġ ����
		if (defence == 1) {
			for (int i = 0; i < Gboard.length; i++) {
				for (int j = 0; j < Gboard.length; j++) {
					if (Gboard[i][j] == Gboard[i + 3][j]) {
						if (Gboard[i - 1][j] != 2 && Gboard[i + 4][j] != 2
								&& Gboard[i - 1][j] != 1
								&& Gboard[i + 4][j] != 1) {
							Gboard[i - 1][j] = Gboard[i + 4][j] = -5;
						}
					} else if (Gboard[i][j] == Gboard[i][j + 3]) {
						if (Gboard[i][j - 1] != 2 && Gboard[i][j + 4] != 2
								&& Gboard[i][j - 1] != 1
								&& Gboard[i][j + 4] != 1) {
							Gboard[i][j - 1] = Gboard[i][j + 4] = -5;
						}
					} else if (Gboard[i][j] == Gboard[i + 3][j + 3]) {
						if (Gboard[i - 1][j - 1] != 2
								&& Gboard[i + 4][j + 4] != 2
								&& Gboard[i - 1][j - 1] != 1
								&& Gboard[i + 4][j + 4] != 1) {
							Gboard[i - 1][j - 1] = Gboard[i + 4][j + 4] = -5;
						}
					} else if (Gboard[i][j] == Gboard[i - 3][j + 3]) {
						if (Gboard[i + 1][j - 1] != 2
								&& Gboard[i - 4][j + 4] != 2
								&& Gboard[i + 1][j - 1] != 1
								&& Gboard[i - 4][j + 4] != 1) {
							Gboard[i + 1][j - 1] = Gboard[i - 4][j + 4] = -5;
						}
					}
				
				if(Gboard[i][j]<Min){
					Min = Gboard[i][j];
					setX = i;
					setY = j; 
					
				}
				}
			}
			
			

		} else {
			// ���� 2�� ���� �� point = 5
			for (int i = 0; i < Gboard.length; i++) {
				for (int j = 0; j < Gboard.length; j++) {
					
					if(Gboard[i][j]>Max){
						Max = Gboard[i][j];
						setX = i;
						setY = j; 
					}
					if (Gboard[i][j] == 1 && Gboard[i][j + 1] == 1) {
						if ((Gboard[i][j - 1] != 1 && Gboard[i][j - 1] != 2)
								&& (Gboard[i][j + 2] != 1 && Gboard[i][j + 2] != 2)) {
							Gboard[i][j - 1] = Gboard[i][j + 2] = 5;
						}
					} else if (Gboard[i][j] == 1 && Gboard[i + 1][j] == 1) {
						if ((Gboard[i - 1][j] != 1 && Gboard[i - 1][j] != 2)
								&& (Gboard[i + 2][j] != 1 && Gboard[i + 2][j] != 2)) {
							Gboard[i - 1][j] = Gboard[i + 2][j] = 5;
						}
					} else if (Gboard[i][j] == 1 && Gboard[i + 1][j + 1] == 1) {
						if ((Gboard[i - 1][j - 1] != 1 && Gboard[i - 1][j - 1] != 2)
								&& (Gboard[i + 2][j + 2] != 1 && Gboard[i + 2][j + 2] != 2)) {
							Gboard[i - 1][j - 1] = Gboard[i + 2][j + 2] = 5;
						}
					} else if (Gboard[i][j] == 1 && Gboard[i - 1][j + 1] == 1) {
						if ((Gboard[i - 2][j + 2] != 1 && Gboard[i - 2][j + 2] != 2)
								&& (Gboard[i + 1][j - 1] != 1 && Gboard[i + 1][j - 1] != 2)) {
							Gboard[i - 2][j + 2] = Gboard[i + 1][j - 1] = 5;
						}
					}
				}
			}
			// ���� 3�� ���� �� point = 7
			for (int i = 0; i < Gboard.length; i++) {
				for (int j = 0; j < Gboard.length; j++) {
					if ((Gboard[i][j] == 1 && Gboard[i][j - 1] == 1)
							&& Gboard[i][j + 1] == 1) {
						if ((Gboard[i][j - 2] != 1 && Gboard[i][j - 2] != 2)
								&& (Gboard[i][j + 2] != 1 && Gboard[i][j + 2] != 2)) {
							Gboard[i][j - 2] = Gboard[i][j + 2] = 7;
						}
					} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j] == 1)
							&& Gboard[i + 1][j] == 1) {
						if ((Gboard[i - 2][j] != 1 && Gboard[i - 2][j] != 2)
								&& (Gboard[i + 2][j] != 1 && Gboard[i + 2][j] != 2)) {
							Gboard[i - 2][j] = Gboard[i + 2][j] = 7;
						}
					} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j + 1] == 1)
							&& Gboard[i + 1][j - 1] == 1) {
						if ((Gboard[i - 2][j + 2] != 1 && Gboard[i - 2][j + 2] != 2)
								&& (Gboard[i + 2][j - 2] != 1 && Gboard[i + 2][j - 2] != 2)) {
							Gboard[i - 2][j + 2] = Gboard[i + 2][j - 2] = 7;
						}
					} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j - 1] == 1)
							&& Gboard[i + 1][j + 1] == 1) {
						if ((Gboard[i - 2][j - 2] != 1 && Gboard[i - 2][j - 2] != 2)
								&& (Gboard[i + 2][j + 2] != 1 && Gboard[i + 2][j + 2] != 2)) {
							Gboard[i - 2][j - 2] = Gboard[i + 2][j + 2] = 7;
						}
					}
				}
			}
			// ���� 4�� ���� �� point = 9
			for (int i = 0; i < Gboard.length; i++) {
				for (int j = 0; j < Gboard.length; j++) {
					if ((Gboard[i][j] == 1 && Gboard[i][j - 1] == 1)
							&& (Gboard[i][j + 1] == 1 && Gboard[i][j - 2] == 1)) { // l���
						if ((Gboard[i][j - 3] != 1 && Gboard[i][j - 3] != 2)
								&& (Gboard[i][j + 2] != 1 && Gboard[i][j + 2] != 2)) {
							Gboard[i][j - 3] = Gboard[i][j + 2] = 9;
						}
					} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j] == 1)
							&& (Gboard[i + 1][j] == 1 && Gboard[i - 2][j] == 1)) { // �Ѹ��
						if ((Gboard[i - 3][j] != 1 && Gboard[i - 3][j] != 2)
								&& (Gboard[i + 2][j] != 1 && Gboard[i + 2][j] != 2)) {
							Gboard[i - 3][j] = Gboard[i + 2][j] = 9;
						}
					} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j + 1] == 1)
							&& (Gboard[i + 1][j - 1] == 1 && Gboard[i + 2][j - 2] == 1)) { // /���
						if ((Gboard[i - 2][j + 2] != 1 && Gboard[i - 2][j + 2] != 2)
								&& (Gboard[i + 3][j - 3] != 1 && Gboard[i + 3][j - 3] != 2)) {
							Gboard[i - 2][j + 2] = Gboard[i + 3][j - 3] = 9;
						}
					} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j - 1] == 1)
							&& (Gboard[i + 1][j + 1] == 1 && Gboard[i - 2][j - 2] == 1)) {// \���
						if ((Gboard[i - 3][j - 3] != 1 && Gboard[i - 3][j - 3] != 2)
								&& (Gboard[i + 2][j + 2] != 1 && Gboard[i + 2][j + 2] != 2)) {
							Gboard[i - 3][j - 3] = Gboard[i + 2][j + 2] = 9;
						}
					} else if (Gboard[i][j] == 1 && Gboard[i][j - 1] == 1
							&& Gboard[i][j + 1] == 1 && Gboard[i][j - 2] == 1
							&& Gboard[i][j - 3] == -1) { // 1_4 l ���
						if (Gboard[i][j + 2] != 1 && Gboard[i][j + 2] != -1) {
							Gboard[i][j + 2] = 9;
						}
					}
				}
			}// �� 4�� ���� ����

		}
		//����ġ ���� ��
		
		Gboard[setX][setY] =1;
		

		for (int i = 0; i < Gboard.length; i++) {
			for (int j = 0; j < Gboard.length; j++) {
				System.out.print(Gboard[i][j]);
			}
			System.out.println("");
		}

	}
	
	// Gboard �迭 �ʱ�ȭ
	public Gravity() {
		Gboard = new int[20][20];
		for (int i = 0; i < Gboard.length; i++) {
			for (int j = 0; j < Gboard.length; j++) {
				Gboard[i][j] = 0;
				System.out.print(Gboard[i][j]);
			}
			System.out.println("");
		}
	}

}

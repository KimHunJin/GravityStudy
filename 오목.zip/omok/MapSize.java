package omok;
/**
 * http://message0412.tistory.com/entry/%EC%9E%90%EB%B0%94-%EC%98%A4%EB%AA%A9%EA%B2%8C%EC%9E%84-%EB%A7%8C%EB%93%A4%EA%B8%B0
 * 
 * 
 **/

public class MapSize {
	private final int CELL = 30;
	private final int SIZE = 20;
	
	public int getCell(){
		return CELL;
	}
	public int getSize(){
		return SIZE;
	}

}

package omokTest;

import java.io.IOException;

public class TestGravity {
	
	public int defense =0;
	static int Gboard[][];
	static int max=0;
	static int min=0;
	private int setX =0;
	public int setY	=0;
	public static void main(String[] args) throws IOException {
		
		int defense =0;
		//checkDefense();
		initGboard();
		Gravity();
		System.out.println(defense);
		
		System.out.println("����");
		
		
		
		System.out.println("defense = "+defense);
		
		
		switch(defense){
		case 0:
			Max(); break;
		case 1:
			Min(); break;
		}
		
		
	}
	
	public static void initGboard(){
		Gboard = new int[20][20];
		for (int i = 0; i < Gboard.length; i++) {
			for (int j = 0; j < Gboard.length; j++) {
				Gboard[i][j] = 0;
				System.out.print(Gboard[i][j]);
			}
			System.out.println("");
		}
	}
	
	public static void Gravity(){
		
		//ó�� ���� ���� 1���� ��
		for (int i = 0; i < Gboard.length; i++) { // ó�� ���� - user�� ���� ���´�.
			for (int j = 0; j < Gboard.length; j++) {
				if (Gboard[i][j] == 2) {
					if (Gboard[i - 1][j - 1] != 2 && Gboard[i][j - 1] != 2
							&& Gboard[i + 1][j - 1] != 2
							&& Gboard[i - 1][j] != 2 && Gboard[i + 1][j] != 2
							&& Gboard[i - 1][j + 1] != 2
							&& Gboard[i][j + 1] != 2
							&& Gboard[i + 1][j + 1] != 2) {
						Gboard[i - 1][j - 1] = Gboard[i][j - 1] = Gboard[i + 1][j - 1] = Gboard[i - 1][j] = Gboard[i + 1][j] = Gboard[i - 1][j + 1] = Gboard[i][j + 1] = 3;
						Gboard[i + 1][j + 1] = 3;
					}
				}
			}
		}// 1�� ��
		for (int i = 0; i < Gboard.length; i++) {
			for (int j = 0; j < Gboard.length; j++) {
				
				if (Gboard[i][j] == 1 && Gboard[i][j + 1] == 1) {
					if ((Gboard[i][j - 1] != 1 && Gboard[i][j - 1] != 2)
							&& (Gboard[i][j + 2] != 1 && Gboard[i][j + 2] != 2)) {
						Gboard[i][j - 1] = Gboard[i][j + 2] = 5;
					}
				} else if (Gboard[i][j] == 1 && Gboard[i + 1][j] == 1) {
					if ((Gboard[i - 1][j] != 1 && Gboard[i - 1][j] != 2)
							&& (Gboard[i + 2][j] != 1 && Gboard[i + 2][j] != 2)) {
						Gboard[i - 1][j] = Gboard[i + 2][j] = 5;
					}
				} else if (Gboard[i][j] == 1 && Gboard[i + 1][j + 1] == 1) {
					if ((Gboard[i - 1][j - 1] != 1 && Gboard[i - 1][j - 1] != 2)
							&& (Gboard[i + 2][j + 2] != 1 && Gboard[i + 2][j + 2] != 2)) {
						Gboard[i - 1][j - 1] = Gboard[i + 2][j + 2] = 5;
					}
				} else if (Gboard[i][j] == 1 && Gboard[i - 1][j + 1] == 1) {
					if ((Gboard[i - 2][j + 2] != 1 && Gboard[i - 2][j + 2] != 2)
							&& (Gboard[i + 1][j - 1] != 1 && Gboard[i + 1][j - 1] != 2)) {
						Gboard[i - 2][j + 2] = Gboard[i + 1][j - 1] = 5;
					}
				}
			}
		}
		// ���� 3�� ���� �� point = 7
		for (int i = 0; i < Gboard.length; i++) {
			for (int j = 0; j < Gboard.length; j++) {
				if ((Gboard[i][j] == 1 && Gboard[i][j - 1] == 1)
						&& Gboard[i][j + 1] == 1) {
					if ((Gboard[i][j - 2] != 1 && Gboard[i][j - 2] != 2)
							&& (Gboard[i][j + 2] != 1 && Gboard[i][j + 2] != 2)) {
						Gboard[i][j - 2] = Gboard[i][j + 2] = 7;
					}
				} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j] == 1)
						&& Gboard[i + 1][j] == 1) {
					if ((Gboard[i - 2][j] != 1 && Gboard[i - 2][j] != 2)
							&& (Gboard[i + 2][j] != 1 && Gboard[i + 2][j] != 2)) {
						Gboard[i - 2][j] = Gboard[i + 2][j] = 7;
					}
				} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j + 1] == 1)
						&& Gboard[i + 1][j - 1] == 1) {
					if ((Gboard[i - 2][j + 2] != 1 && Gboard[i - 2][j + 2] != 2)
							&& (Gboard[i + 2][j - 2] != 1 && Gboard[i + 2][j - 2] != 2)) {
						Gboard[i - 2][j + 2] = Gboard[i + 2][j - 2] = 7;
					}
				} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j - 1] == 1)
						&& Gboard[i + 1][j + 1] == 1) {
					if ((Gboard[i - 2][j - 2] != 1 && Gboard[i - 2][j - 2] != 2)
							&& (Gboard[i + 2][j + 2] != 1 && Gboard[i + 2][j + 2] != 2)) {
						Gboard[i - 2][j - 2] = Gboard[i + 2][j + 2] = 7;
					}
				}
			}
		}
		// ���� 4�� ���� �� point = 9
		for (int i = 0; i < Gboard.length; i++) {
			for (int j = 0; j < Gboard.length; j++) {
				if ((Gboard[i][j] == 1 && Gboard[i][j - 1] == 1)
						&& (Gboard[i][j + 1] == 1 && Gboard[i][j - 2] == 1)) { // l���
					if ((Gboard[i][j - 3] != 1 && Gboard[i][j - 3] != 2)
							&& (Gboard[i][j + 2] != 1 && Gboard[i][j + 2] != 2)) {
						Gboard[i][j - 3] = Gboard[i][j + 2] = 9;
					}
				} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j] == 1)
						&& (Gboard[i + 1][j] == 1 && Gboard[i - 2][j] == 1)) { // �Ѹ��
					if ((Gboard[i - 3][j] != 1 && Gboard[i - 3][j] != 2)
							&& (Gboard[i + 2][j] != 1 && Gboard[i + 2][j] != 2)) {
						Gboard[i - 3][j] = Gboard[i + 2][j] = 9;
					}
				} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j + 1] == 1)
						&& (Gboard[i + 1][j - 1] == 1 && Gboard[i + 2][j - 2] == 1)) { // /���
					if ((Gboard[i - 2][j + 2] != 1 && Gboard[i - 2][j + 2] != 2)
							&& (Gboard[i + 3][j - 3] != 1 && Gboard[i + 3][j - 3] != 2)) {
						Gboard[i - 2][j + 2] = Gboard[i + 3][j - 3] = 9;
					}
				} else if ((Gboard[i][j] == 1 && Gboard[i - 1][j - 1] == 1)
						&& (Gboard[i + 1][j + 1] == 1 && Gboard[i - 2][j - 2] == 1)) {// \���
					if ((Gboard[i - 3][j - 3] != 1 && Gboard[i - 3][j - 3] != 2)
							&& (Gboard[i + 2][j + 2] != 1 && Gboard[i + 2][j + 2] != 2)) {
						Gboard[i - 3][j - 3] = Gboard[i + 2][j + 2] = 9;
					}
				} else if (Gboard[i][j] == 1 && Gboard[i][j - 1] == 1
						&& Gboard[i][j + 1] == 1 && Gboard[i][j - 2] == 1
						&& Gboard[i][j - 3] == -1) { // 1_4 l ���
					if (Gboard[i][j + 2] != 1 && Gboard[i][j + 2] != -1) {
						Gboard[i][j + 2] = 9;
					}
				}
			}
		}// �� 4�� ���� ����
	}
	
	public static int checkDefense(){
		
		int defense =0;
		
		for(int i =0;i<Gboard.length;i++){
			for(int j=0; j<Gboard.length; j++){
				if (Gboard[i][j] == 2 && Gboard[i - 1][j] == 2 && Gboard[i + 1][j] == 2){
					defense = 1;
				}else if(Gboard[i][j] == 2 && Gboard[i][j - 1] == 2 && Gboard[i][j + 1] == 2){
					defense = 1;
				}else if(Gboard[i][j] == 2 && Gboard[i - 1][j + 1] == 2 && Gboard[i + 1][j - 1] == 2){
					defense = 1;
				}else if(Gboard[i][j] == 2 && Gboard[i - 1][j - 1] == 2 && Gboard[i + 1][j + 1] == 2) {
					defense = 1;
				} else {
					defense = 0;
				}

			}
		}
		return defense;
	}
	
	public static void Max(){
		int setX=0; int setY=0;
		for(int i=0; i<Gboard.length;i++){
			for(int j =0; j<Gboard.length;j++){
				if(Gboard[i][j]>max){
					max = Gboard[i][j];
					setX =i;
					setY = j;
				}
			}
		}
		
		Gboard[setX][setY]=1;
		
	}
	public static void Min(){
		
		int setX=0; int setY=0;
		for(int i=0; i<Gboard.length;i++){
			for(int j =0; j<Gboard.length;j++){
				if(Gboard[i][j]<min){
					min = Gboard[i][j];
					setX =i;
					setY = j;
				}
			}
	}
		Gboard[setX][setY]=1;
	}

}
